<?php

use Illuminate\Database\Eloquent\Model;

class M_user extends Model {
	protected $table = 'user';
	public $timestamps = false;
	protected $fillable = [
		'id',
		'nama',
		'notelp',
		'username',
		'password'];
}


?>